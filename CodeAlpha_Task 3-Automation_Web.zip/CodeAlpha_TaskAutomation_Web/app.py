from flask import Flask, render_template
import os
import shutil

app = Flask(__name__)

SOURCE_FOLDER = "source_folder"
DEST_FOLDER = "destination_folder"


@app.route('/')
def home():
    # Count JPG files in source folder
    source_files = [
        f for f in os.listdir(SOURCE_FOLDER)
        if f.endswith(".jpg")
    ]

    # Count JPG files in destination folder
    if not os.path.exists(DEST_FOLDER):
        os.makedirs(DEST_FOLDER)

    dest_files = [
        f for f in os.listdir(DEST_FOLDER)
        if f.endswith(".jpg")
    ]

    return render_template(
        "index.html",
        source_count=len(source_files),
        dest_count=len(dest_files)
    )


@app.route('/move-files')
def move_files():
    moved_files = []

    if not os.path.exists(DEST_FOLDER):
        os.makedirs(DEST_FOLDER)

    # Move JPG files
    for file in os.listdir(SOURCE_FOLDER):
        if file.endswith(".jpg"):
            source_path = os.path.join(SOURCE_FOLDER, file)
            dest_path = os.path.join(DEST_FOLDER, file)

            shutil.move(source_path, dest_path)
            moved_files.append(file)

    # Updated counts
    source_count = len([
        f for f in os.listdir(SOURCE_FOLDER)
        if f.endswith(".jpg")
    ])

    dest_count = len([
        f for f in os.listdir(DEST_FOLDER)
        if f.endswith(".jpg")
    ])

    return render_template(
        "index.html",
        files=moved_files,
        message="Task completed successfully!",
        source_count=source_count,
        dest_count=dest_count
    )


if __name__ == '__main__':
    app.run(debug=True)