from flask import Flask, render_template, request

app = Flask(__name__)

def get_bot_reply(user):
    user = user.lower().strip()

    if user in ["hello", "hi"]:
        return "Hello! Nice to meet you 😊"
    elif user == "how are you":
        return "I'm doing great, thanks for asking!"
    elif user == "what is your name":
        return "I'm your CodeAlpha Chatbot 🤖"
    elif user == "who created you":
        return "I was created using Python and Flask."
    elif user == "bye":
        return "Goodbye! Have a great day 👋"
    else:
        return "Sorry, I don't understand that."

@app.route("/", methods=["GET", "POST"])
def home():
    user_message = ""
    bot_reply = ""

    if request.method == "POST":
        user_message = request.form["message"]
        bot_reply = get_bot_reply(user_message)

    return render_template(
        "index.html",
        user_message=user_message,
        bot_reply=bot_reply
    )

if __name__ == "__main__":
    app.run(debug=True)